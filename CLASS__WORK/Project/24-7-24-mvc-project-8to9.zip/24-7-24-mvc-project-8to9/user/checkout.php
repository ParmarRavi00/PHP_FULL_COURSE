<?php include 'header.php' ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-xl-6">
        <div class="">
  <h1 class="display-4">Hello, world!</h1>
 
  <hr class="my-4">
  <p>It uses razor pay payment gatway  for payment</p>
  <p>Amount : 878998 </p>
  
  <p class="lead">
    <button class="btn btn-primary btn-lg" href="#" role="button">Pay</button>
  </p>
</div>
        </div>
    </div>
</div>
<?php include 'footer.php' ?>