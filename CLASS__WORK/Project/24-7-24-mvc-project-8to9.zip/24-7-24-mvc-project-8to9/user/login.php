<?php include 'header.php' ?>
<!-- contact section -->
<section class=" layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <form method="post">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email address</label>
                        <input type="email" 
                        name="uemail"
                        class="form-control"
                        value="<?php
                        if(isset($_COOKIE['uemail']))
                        echo $_COOKIE['uemail'];
                        ?>"
                        aria-describedby="emailHelp">
                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password"
                        name="upassword" class="form-control"  value="<?php
                        if(isset($_COOKIE['upassword']))
                        echo $_COOKIE['upassword'];
                        ?>">
                    </div>
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" name="remember">
                        <label class="form-check-label" for="exampleCheck1">Remember Me</label>
                    </div>
                    <div class="form-group">
                       <a href="">Forgot Password?</a>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary">Login</button>
                </form>
            </div>
          
        </div>
    </div>
</section>

<!-- end contact section -->
<?php include 'footer.php' ?>