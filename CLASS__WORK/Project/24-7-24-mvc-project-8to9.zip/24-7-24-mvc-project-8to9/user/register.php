<?php include 'header.php' ?>
<!-- contact section -->
<section class=" layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="">Name</label>
                        <input type="text" class="form-control" id="" placeholder="Enter name" name="uname">
                    </div>
                    <div class="form-group">
                        <label for="">Email address</label>
                        <input type="email" class="form-control" id="" aria-describedby="emailHelp" placeholder="Enter email" name="uemail">
                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                        <label for="">Enter Password</label>
                        <input type="password" class="form-control" id="" placeholder="Enter password" name="upwd">
                    </div>
                    <div class="form-group">
                        <label for="">Confirm Password</label>
                        <input type="password" class="form-control" id="" placeholder="Confirm password" name="ucpwd">
                    </div>

                    <div class="form-group">
                        <label for="">Mobile</label>
                        <input type="text" class="form-control" id="" placeholder="Enter mobile" name="umobile">
                    </div>

                    <div class="form-group">
                        <label for="">Address</label>
                        <textarea  id="" class="form-control" name="uaddress"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="">Gender</label>
                        <div class="form-check-inline">
                            <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="gender" value="Male"> Male
                            </label>
                        </div>
                        <div class="form-check-inline">
                            <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="gender" value="Female"> Female
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="">Languages</label>
                        <div class="form-check-inline">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input" value="Gujarati" name="chk[]"> Gujarati
                            </label>
                        </div>
                        <div class="form-check-inline">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input" value="Hindi"  name="chk[]"> Hindi
                            </label>
                        </div>
                        <div class="form-check-inline">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input" value="English"  name="chk[]"> English
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="">Upload file</label>
                        <input type="file" class="form-control" id="" name="uimage">
                    </div>

                    <button type="submit" class="btn btn-primary" name="register">Register</button>
                </form>
            </div>

        </div>
    </div>
</section>

<!-- end contact section -->
<?php include 'footer.php' ?>