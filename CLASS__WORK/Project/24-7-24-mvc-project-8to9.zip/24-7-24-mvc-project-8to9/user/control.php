<?php

require 'model.php';

class control extends model
{
    function __construct()
    {
        session_start();
        model::__construct();
        $url = $_SERVER['PATH_INFO'];

        switch ($url) {
            case "/index":

                include 'index.php';
                break;

            case "/login":
                if(isset($_REQUEST['login']))
                {
                    $email = $_REQUEST['uemail'];
                    $password = $_REQUEST['upassword'];

                    $where = array('u_email'=>$email);

                    $run = $this->select_where('users',$where);

                    $fetch = $run->fetch_object();

                    $dbEmail = $fetch->u_email;// dbemail
                    $dbPwd = $fetch->u_password;// dbemail
                    $dbName = $fetch->u_name;// dbemail
                    
                    // echo $dbEmail;exit;

                    // setcookie('name','value',time)

                    if(isset($_REQUEST['remember']))
                    {
                        setcookie('uemail',$email,time()+20);
                        setcookie('upassword',$password,time()+20);
                    }

                   

                    $_SESSION['uemail'] =  $dbEmail;
                    $_SESSION['uname'] =  $dbName;
                    
                    if($dbEmail == $email && $dbPwd == $password)
                    {
                        echo "<script>
                        alert('Welcome user')
                        window.location.href= 'index'
                        </script>";
                    }
                    else 
                    {
                        echo "<script>
                        alert('Invalid Username/Password...!')
                        </script>";
                    }
                }
               
                include 'login.php';
                break;

                case "/logout":

                    // unset($_SESSION['uemail']);
                    // unset($_SESSION['uname']);
                    session_destroy();
                    echo "<script>
                        alert('come back soon...!')
                        window.location.href = 'index'
                        </script>"; 
                    break;

            case "/register":

                if(isset($_REQUEST['register']))
                {
                    $name = $_REQUEST['uname'];
                    $email = $_REQUEST['uemail'];
                    $password = $_REQUEST['upwd'];
                    $mobile = $_REQUEST['umobile'];
                    $address =  $_REQUEST['uaddress'];
                    $gender = $_REQUEST['gender'];
                    $languages = $_REQUEST['chk'];

                    $lang = "";

                    foreach($languages as $language)
                    {
                        $lang.=$language.",";
                    }
                    
                    $img = $_FILES['uimage']['name'];
                    $dup_img = $_FILES['uimage']['tmp_name'];
                    $path = 'uploads/'.$img;
                    move_uploaded_file($dup_img,$path);

                    $data = array('u_name'=>$name,'u_email'=>$email,'u_password'=>$password,'u_mobile'=>$mobile,'u_address'=>$address,'u_gender'=>$gender,'u_languages'=>$lang,'u_image'=> $img);

                   $insert =  $this->insert('users',$data);

                   if($insert)
                   {
                    echo "<script> alert('Record inserted..!) </script>";
                   }
                   
                }

                include 'register.php';
                break;

            case "/about":

                include 'about.php';
                break;

            case "/jewellery":

                include 'jewellery.php';
                break;
            case "/single-jewellery":

                include 'single-jewellery.php';
                break;

            case "/cart":

                include 'cart.php';
                break;

            case "/checkout":

                include 'checkout.php';
                break;

            case "/contact":

                include 'contact.php';
                break;
        }
    }
}

$obj = new control();
