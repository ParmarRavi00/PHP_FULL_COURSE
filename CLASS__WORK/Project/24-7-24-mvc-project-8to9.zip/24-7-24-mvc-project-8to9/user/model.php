<?php 

class model 
{
  
    public $conn="";
    function __construct()
    {
        $this->conn = new mysqli('localhost','root','','29-7-24-jewellery');

        // if($this->conn)
        // {
        //     echo "connected...!";
        // }
    }

    //'insert into table (col1,col2,col3,...)' values ('val1','val2','val3',...)
    // ('users',array('u_name'=>$name,'u_email'=>"sdlf@gmail.com'))
    // ('cart',array('qty'=>$qty))
     // ('categoty',array('cate_name'=>$cate_name))
    function insert($table,$data) // $data = array('u_name'=>$name,'u_email'=>$email)
    {
        $col_arr = array_keys($data);//u_name,u_email
        $val_arr = array_values($data);//Raviraj,r@gmail.com

        $col = implode(",",$col_arr);
        $val = implode("','",$val_arr);

        // insert into users (u_name,u_email,u_password,u_mobile,u_address,u_gender,u_languages,u_image) values('Raviraj','1234','067754645645','Ahd','Male',Array,'tree-736885_1280.jpg');


        $sql = "insert into $table ($col) values('$val')";

        // echo $sql;exit();
        $run = $this->conn->query($sql);

        return $run;

    }

    function select_where($table,$where)
    {
        $col_arr = array_keys($where);//u_name,u_email
        $val_arr = array_values($where);//Raviraj,r@gmail.com

        $select = "select * from $table where 1=1";
//select * from $table where 1=1 and $col_arr[0] = '$val_arr[0] and $col_arr[1] = '$val_arr[1]'

        $i=0;
        foreach($where as $w)
        {
            $select.= " and $col_arr[$i] = '$val_arr[$i]'";
            $i++;
        }
        // echo $select;exit();
        $run = $this->conn->query($select);
        return $run;
    }
}